package com.steam.datahanding.mapper;

public interface DatahandingMapper {
}
