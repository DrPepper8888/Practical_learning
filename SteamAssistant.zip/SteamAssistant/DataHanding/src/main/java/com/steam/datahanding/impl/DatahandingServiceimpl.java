package com.steam.datahanding.impl;

import com.steam.datahanding.mapper.DatahandingMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DatahandingServiceimpl {
}
